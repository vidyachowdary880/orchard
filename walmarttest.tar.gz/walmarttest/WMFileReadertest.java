package com.sellerworx.modules.walmartassigntest;

import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.impl.DefaultExchange;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit4.SpringRunner;

import com.sellerworx.Application;
import com.sellerworx.darby.util.ExchangeHeaderKeys;
import com.sellerworx.darby.util.TenantConfigKeys;
import com.sellerworx.modules.walmart.request.InventoryBatchDetails;
import com.sellerworx.modules.walmartassgn.Waltest;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { Application.class }, webEnvironment = WebEnvironment.RANDOM_PORT)
public class WMFileReadertest {
	  @Autowired
	    private CamelContext camelContext;

	    private Exchange camelExchange;
	    private Map<String, String> tenantConfigMap = new HashMap<String, String>();
	 
	@Autowired

	Waltest  waltest;
	
	  private static final String JSON_FILE_NAME = "InventoryBatch_20171213084112822.json";
	  @Before
	    public void buildExchange() {
		  camelExchange = new DefaultExchange(camelContext);
			
			ClassLoader classLoader = getClass().getClassLoader();
	        String jsonFile = new File(classLoader.getResource(JSON_FILE_NAME).getFile()).toString();
		  tenantConfigMap = new HashMap<String, String>();
		  tenantConfigMap.put(TenantConfigKeys.FILE_PATH,jsonFile);
		  camelExchange.getIn().setHeader(ExchangeHeaderKeys.TENANT_CONFIG_MAP, tenantConfigMap);
	  }
	  
	@Test
	public void test() throws IOException {
		InventoryBatchDetails testobj=new  InventoryBatchDetails();
		testobj.setClubNumber("4723");
		 
		testobj.setItemNumber( "18133");
		 testobj.setBatchDetails( "ABC_TEST#20171017#20171012");
		 
		List<InventoryBatchDetails> expected = new ArrayList<>();
        expected.add(testobj);
        
        List<InventoryBatchDetails> actuallist=waltest.exprocess(null , tenantConfigMap);
        Assert.assertEquals(expected, actuallist);
        
 
	}

}
