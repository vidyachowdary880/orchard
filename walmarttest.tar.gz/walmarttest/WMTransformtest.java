package com.sellerworx.modules.walmartassigntest;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.impl.DefaultExchange;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.sellerworx.Application;
import com.sellerworx.darby.model.Tenant;
import com.sellerworx.darby.util.ExchangeHeaderKeys;
import com.sellerworx.modules.mapping.MappingService;
import com.sellerworx.modules.mapping.model.Item;
 
import com.sellerworx.modules.walmart.request.InventoryBatchDetails;
import com.sellerworx.modules.walmartassgn.WalmartTransform;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { Application.class }, webEnvironment = WebEnvironment.RANDOM_PORT)
public class WMTransformtest {

	private static final String PRODUCTATTRIBUTE_CUSTOMFIELD = "batchAttributeRefCode";
	private Logger logger = LoggerFactory.getLogger(WMTransformtest.class);
	private final String WM_ITEM_STORE = "Batchno_4723";
	private final String WM_BATCH_ATTRIBUTE_ITEM_ALIAS = "WM_BATCH_ATTRIBUTE";
	 @Autowired
	    private CamelContext camelContext;
	 @Autowired
	 WalmartTransform walmarttransform;

	    private Exchange camelExchange;

	@MockBean
	private MappingService mappingService;

	@Before
	public void buildExchange() {
		camelExchange = new DefaultExchange(camelContext);
		Tenant tenant = new Tenant();
		tenant.setId((long) 7);

		Item item = new Item();
		item.setId(new Long("1338"));

		item.setMasterId("Batchno_4723");
		 
		
		Map<String, InventoryBatchDetails> articleKeyGenMap = new HashMap<String, InventoryBatchDetails>();
		InventoryBatchDetails batchdetails = new InventoryBatchDetails();
		batchdetails.setBatchDetails("ABC_TEST#20171017#20171012");
		batchdetails.setItemNumber("296635");
		batchdetails.setClubNumber("4723");
		articleKeyGenMap.put("4723_296635", batchdetails);
		List<InventoryBatchDetails> processlist = articleKeyGenMap.values().stream().collect(Collectors.toList());
		Mockito.when(mappingService.getItem(Mockito.eq(tenant.getId()), Mockito.anyString())).thenReturn(item);
		 Mockito.when(mappingService.map(tenant.getId(), WM_ITEM_STORE, WM_BATCH_ATTRIBUTE_ITEM_ALIAS)).thenReturn(
	                "CK00002490-005");
		 camelExchange.getIn().setBody(processlist);
		 camelExchange.getIn().setHeader( "tenant", tenant);
	}

	@Test
	public void InventoryRefermcecodetest() {
		Tenant tenant=(Tenant) camelExchange.getIn().getHeader("tenant");
		Item item = new Item();
		item.setId(new Long("1338"));

		item.setMasterId("Batchno_4723");
		Assert.assertEquals("CK00002490-005", walmarttransform.getMappedAttributeId(  tenant ,"Batchno_4723")) ;
		
	}
	 
	 
	 

}
