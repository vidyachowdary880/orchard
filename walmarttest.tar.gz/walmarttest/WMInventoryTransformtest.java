package com.sellerworx.modules.walmartassigntest;

import static org.junit.Assert.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.impl.DefaultExchange;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.sellerworx.Application;
import com.sellerworx.darby.model.Tenant;
import com.sellerworx.darby.util.ExchangeHeaderKeys;
import com.sellerworx.darby.util.TenantConfigKeys;
import com.sellerworx.modules.martjack.services.CatalogService;
 
import com.sellerworx.modules.walmart.request.InventoryBatchDetails;
import com.sellerworx.modules.walmartassgn.WMFilePush;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { Application.class }, webEnvironment = WebEnvironment.RANDOM_PORT)
public class WMInventoryTransformtest {
	 private Logger logger = LoggerFactory.getLogger(WMInventoryTransformtest  .class);
	 private final String PRODUCTATTRIBUTE_CUSTOMFIELD = "batchAttributeRefCode";
	    @Autowired
	    private CamelContext camelContext;
	    @Autowired
	    private WMFilePush wmfilepush;

	    private Exchange camelExchange;

	    @MockBean
	    private CatalogService catalogService;

	    private Map<String, String> tenantConfigMap = new HashMap<String, String>();
	    @Before
	    public void buildExchange() {
	    	
	    Tenant tenant=new Tenant();
	    tenant.setId( (long) (7));
	         
	        camelExchange = new DefaultExchange(camelContext);
	        camelExchange.getIn().setHeader(ExchangeHeaderKeys.TENANT, tenant);
	        tenantConfigMap = new HashMap<String, String>();
	        tenantConfigMap.put(TenantConfigKeys.DEFAULT_RETRY_LIMIT, "2");
	        tenantConfigMap.put(TenantConfigKeys.DEFAULT_RETRY_DELAY, "1000");
	        tenantConfigMap.put(TenantConfigKeys.MJ_MERCHANT_ID, "2f9b7c67-7c32-4267-9132-abb503dc4c83");
	        tenantConfigMap.put(TenantConfigKeys.MJ_MERCHANT_CONSUMER_KEY, "HLBOUGY2");
	        tenantConfigMap.put(TenantConfigKeys.MJ_MERCHANT_CONSUMER_SECRET, "OEL1WFN8V1HWLDRCF57ZSWMB");
	        tenantConfigMap.put(TenantConfigKeys.MJ_HOST, "http://www.stagewm.martjack.com/devapi");
	        camelExchange.getIn().setHeader(ExchangeHeaderKeys.TENANT_CONFIG_MAP, tenantConfigMap);
	        Map<String, InventoryBatchDetails> articleKeyGenMap = new HashMap<String, InventoryBatchDetails>();
	        InventoryBatchDetails batchdetails = new InventoryBatchDetails();
	        batchdetails.setBatchDetails("ABC_TEST#20171017#20171012");
	        batchdetails.setItemNumber("18133");
	        batchdetails.setClubNumber("4723");
	        articleKeyGenMap.put("4723-18133", batchdetails);
	        List<InventoryBatchDetails> processlist = articleKeyGenMap.values().stream().collect(Collectors.toList());
	        camelExchange.getIn().setBody(processlist);
	    }
	@Test
	public void APIcalltest() throws Exception {
		 
		 wmfilepush.process(camelExchange) ;
		 try {
	            Mockito.verify(catalogService, Mockito.times(1)).updateProductAttributes(Mockito.isA(String.class),
	                    Mockito.isA(String.class), Mockito.isA(JSONObject.class), Mockito.isA(String.class),
	                    Mockito.isA(String.class));
	        } catch (IOException e) {
	            logger.info("error while pushing data to mj service - " + e.getMessage());
	        }

	        
	        
	            
	       
	}

}
